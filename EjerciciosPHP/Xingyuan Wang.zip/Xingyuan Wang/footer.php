<footer style="background-color: #f4f4f4; padding: 10px; text-align: center; width: 100%;">
    <p>© 2024 Xingyuan Wang - 2DW3A</p>
</footer>
